Floatbox.prototype.getMousedownHandler = function() {
	var t = this;
	return function(e) {
		if (!(t.currentItem && t.fbContent)) return;
		e = e || window.event;
		var target = e.target || e.srcElement,
			item = t.currentItem,
			startX = e.clientX,
			startY = e.clientY,
			box = t.fbBox.style,
			mainDiv = t.fbMainDiv.style,
			content = t.fbContent.style,
			posBox = t.pos.fbBox;
		if (target.id === 'fbDragger') {
			var proportional = (item.type === 'img' || item.type.indexOf('media') === 0);
			if (typeof item.options.proportionalResize === 'boolean') {
				proportional = item.options.proportionalResize;
			}
			if (proportional) {
				var w = typeof item.nativeWidth === 'number' ? item.nativeWidth : t.pos.fbMainDiv.width,
					h = typeof item.nativeHeight === 'number' ? item.nativeHeight : t.pos.fbMainDiv.height,
					ratio = w / h;
			}
			startX -= t.dragResizeDx;
			startY -= t.dragResizeDy;
			t.bod.style.cursor = 'nw-resize';
			t.dragResizing = true;
		} else if (/fb(Box|Corner|Canvas|InfoPanel|CaptionDiv|ControlPanel|IndexLinks)/.test(target.id)) {
			var boxX = posBox.left,
				boxY = posBox.top;
			t.bod.style.cursor = 'move';
			t.dragResizing = false;
		} else {
			return;
		}
		var upHandler = function(e) {
			e = e || window.event;
			t.clearTimeout('mouseup');
			if (document.removeEventListener) {
				document.removeEventListener("mouseup", upHandler, true);
				document.removeEventListener("mousemove", moveHandler, true);
			} else if (t.fbBox.detachEvent) {
				t.fbBox.detachEvent("onlosecapture", upHandler);
				t.fbBox.detachEvent("onmouseup", upHandler);
				t.fbBox.detachEvent("onmousemove", moveHandler);
				t.fbBox.releaseCapture();
			}
			if (t.dragResizing) {
				t.dragResizing = false;
			} else if (t.stickyDragMove) {
				t.dragMoveDx += posBox.left - boxX;
				t.dragMoveDy += posBox.top - boxY;
			}
		  	t.leftRatio = t.topRatio = false;
			t.bod.style.cursor = 'default';
			content.visibility = '';
			return t.stopEvent(e);
		};
		var moveHandler = function(e) {
			e = e || window.event;
			if (item.type === 'iframe' && !content.visibility) content.visibility = 'hidden';
			if (t.isSlideshow && !t.isPaused) t.setPause(true);
			var dx = e.clientX - startX,
				dy = e.clientY - startY;
			if (t.dragResizing) {
				if (proportional) {
					var dragTotal = dx + dy;
					dy = dragTotal / (ratio + 1);
					dx = dragTotal - dy;
				}
				t.dragResizeDx = dx;
				t.dragResizeDy = dy;
				t.calcSize(false);
			} else {
				box.left = (posBox.left = boxX + dx) + 'px';
				box.top = (posBox.top = boxY + dy) + 'px';
			}
			t.clearTimeout('mouseup');
			t.setTimeout('mouseup', upHandler, 1500);
			return t.stopEvent(e);
		};
		if (document.addEventListener) {
			document.addEventListener("mousemove", moveHandler, true);
			document.addEventListener("mouseup", upHandler, true);
		} else if (t.fbBox.attachEvent) {
			t.fbBox.setCapture();
			t.fbBox.attachEvent("onmousemove", moveHandler);
			t.fbBox.attachEvent("onmouseup", upHandler);
			t.fbBox.attachEvent("onlosecapture", upHandler);
		}
		return t.stopEvent(e);
	};
};
if ((fb.enableDragMove || fb.enableDragResize) && fb.fbBox && !fb.fbBox.onmousedown) fb.fbBox.onmousedown = fb.getMousedownHandler;
Floatbox.prototype.getMousedownHandler=function(){var A=this;return function(K){if(!(A.currentItem&&A.fbContent)){return }K=K||window.event;var L=K.target||K.srcElement,Q=A.currentItem,I=K.clientX,F=K.clientY,H=A.fbBox.style,E=A.fbMainDiv.style,M=A.fbContent.style,D=A.pos.fbBox;if(L.id==="fbDragger"){var C=(Q.type==="img"||Q.type.indexOf("media")===0);if(typeof Q.options.proportionalResize==="boolean"){C=Q.options.proportionalResize}if(C){var O=typeof Q.nativeWidth==="number"?Q.nativeWidth:A.pos.fbMainDiv.width,G=typeof Q.nativeHeight==="number"?Q.nativeHeight:A.pos.fbMainDiv.height,N=O/G}I-=A.dragResizeDx;F-=A.dragResizeDy;A.bod.style.cursor="nw-resize";A.dragResizing=true}else{if(/fb(Box|Corner|Canvas|InfoPanel|CaptionDiv|ControlPanel|IndexLinks)/.test(L.id)){var R=D.left,P=D.top;A.bod.style.cursor="move";A.dragResizing=false}else{return }}var B=function(S){S=S||window.event;A.clearTimeout("mouseup");if(document.removeEventListener){document.removeEventListener("mouseup",B,true);document.removeEventListener("mousemove",J,true)}else{if(A.fbBox.detachEvent){A.fbBox.detachEvent("onlosecapture",B);A.fbBox.detachEvent("onmouseup",B);A.fbBox.detachEvent("onmousemove",J);A.fbBox.releaseCapture()}}if(A.dragResizing){A.dragResizing=false}else{if(A.stickyDragMove){A.dragMoveDx+=D.left-R;A.dragMoveDy+=D.top-P}}A.leftRatio=A.topRatio=false;A.bod.style.cursor="default";M.visibility="";return A.stopEvent(S)};var J=function(V){V=V||window.event;if(Q.type==="iframe"&&!M.visibility){M.visibility="hidden"}if(A.isSlideshow&&!A.isPaused){A.setPause(true)}var T=V.clientX-I,S=V.clientY-F;if(A.dragResizing){if(C){var U=T+S;S=U/(N+1);T=U-S}A.dragResizeDx=T;A.dragResizeDy=S;A.calcSize(false)}else{H.left=(D.left=R+T)+"px";H.top=(D.top=P+S)+"px"}A.clearTimeout("mouseup");A.setTimeout("mouseup",B,1500);return A.stopEvent(V)};if(document.addEventListener){document.addEventListener("mousemove",J,true);document.addEventListener("mouseup",B,true)}else{if(A.fbBox.attachEvent){A.fbBox.setCapture();A.fbBox.attachEvent("onmousemove",J);A.fbBox.attachEvent("onmouseup",B);A.fbBox.attachEvent("onlosecapture",B)}}return A.stopEvent(K)}};if((fb.enableDragMove||fb.enableDragResize)&&fb.fbBox&&!fb.fbBox.onmousedown){fb.fbBox.onmousedown=fb.getMousedownHandler};